package dev.marvelcosmic;

import dev.marvelcosmic.item.HeroItems;
import net.minecraft.network.chat.Component;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import net.neoforged.neoforge.event.server.ServerStartingEvent;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.bus.api.SubscribeEvent;
import net.minecraft.commands.Commands;

@Mod(MarvelCosmic.MOD_ID)
public final class MarvelCosmic {
    public static final String MOD_ID = "marvelcosmic";

    public MarvelCosmic(IEventBus modEventBus) {
        HeroItems.ITEMS.register(modEventBus);
        NeoForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void onServerStarting(ServerStartingEvent event) {
        event.getServer().getPlayerList().broadcastSystemMessage(
                Component.literal("Marvel Cosmic loaded! Try /marvelcosmic"), false);
    }

    @SubscribeEvent
    public void registerCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("marvelcosmic")
                .executes(context -> {
                    context.getSource().sendSuccess(
                            () -> Component.literal("Marvel Cosmic v0.1.0 — use hero tokens from the Creative inventory."),
                            false);
                    return 1;
                }));
    }
}
