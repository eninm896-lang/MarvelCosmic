package dev.marvelcosmic.item;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public final class HeroTokenItem extends Item {
    private final HeroPower power;

    public HeroTokenItem(Properties properties, HeroPower power) {
        super(properties);
        this.power = power;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide && level instanceof ServerLevel) {
            switch (power) {
                case IRON_MAN -> {
                    player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 20 * 20, 1));
                    player.addEffect(new MobEffectInstance(MobEffects.JUMP, 20 * 20, 1));
                    player.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 20 * 20, 0));
                }
                case SPIDER_MAN -> {
                    player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 20 * 25, 2));
                    player.addEffect(new MobEffectInstance(MobEffects.JUMP, 20 * 25, 2));
                    player.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 20 * 25, 0));
                }
                case THOR -> {
                    player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 20 * 20, 1));
                    player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 20 * 20, 1));
                }
                case THANOS -> {
                    player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 20 * 15, 2));
                    player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 20 * 15, 1));
                    player.addEffect(new MobEffectInstance(MobEffects.GLOWING, 20 * 15, 0));
                }
            }
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }
}
