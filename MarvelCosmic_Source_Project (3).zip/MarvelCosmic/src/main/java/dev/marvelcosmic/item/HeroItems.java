package dev.marvelcosmic.item;

import dev.marvelcosmic.MarvelCosmic;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;

import java.util.function.Supplier;

public final class HeroItems {
    public static final DeferredRegister.Items ITEMS =
            DeferredRegister.createItems(MarvelCosmic.MOD_ID);

    public static final DeferredItem<Item> IRON_MAN_CORE =
            ITEMS.register("iron_man_core", () -> new HeroTokenItem(
                    new Item.Properties().stacksTo(1).rarity(Rarity.EPIC), HeroPower.IRON_MAN));
    public static final DeferredItem<Item> SPIDER_TOTEM =
            ITEMS.register("spider_totem", () -> new HeroTokenItem(
                    new Item.Properties().stacksTo(1).rarity(Rarity.RARE), HeroPower.SPIDER_MAN));
    public static final DeferredItem<Item> THOR_EMBLEM =
            ITEMS.register("thor_emblem", () -> new HeroTokenItem(
                    new Item.Properties().stacksTo(1).rarity(Rarity.EPIC), HeroPower.THOR));
    public static final DeferredItem<Item> THANOS_RELIC =
            ITEMS.register("thanos_relic", () -> new HeroTokenItem(
                    new Item.Properties().stacksTo(1).rarity(Rarity.EPIC), HeroPower.THANOS));

    private HeroItems() {}
}
