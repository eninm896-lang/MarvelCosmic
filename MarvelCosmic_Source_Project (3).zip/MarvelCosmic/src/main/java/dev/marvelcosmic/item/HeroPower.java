package dev.marvelcosmic.item;

public enum HeroPower {
    IRON_MAN,
    SPIDER_MAN,
    THOR,
    THANOS
}
